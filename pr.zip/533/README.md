# EGI Documentation

> This project is only used to host the generated documentation and is not
> meant to receive Pull Requests.
>
> In case you would like to open an issue or Pull Request please do it in the
> [EGI-Federation/documentation](https://github.com/EGI-Federation/documentation)
> repository.
